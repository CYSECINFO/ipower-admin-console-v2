from mailjet_rest import Client
import os
import requests
response = requests.get("https://api.callmebot.com/signal/send.php?phone=+916296818976&apikey=327849&text=Your request was successfully submitted for capturing photo from rear camera")
print(response)



api_key = '1bc77353cbd0a66e61252dc06b8440c8'
api_secret = 'ece40fadb044b559cc17e9710f180307'
mailjet = Client(auth=(api_key, api_secret), version='v3.1')
data = {
  'Messages': [
    {
      "From": {
        "Email": "dipjoydas63@gmail.com",
        "Name": "Dipjoy"
      },
      "To": [
        {
          "Email": "dipjoydas63@gmail.com",
          "Name": "Dipjoy"
        }
      ],
      "Subject": "from ipower admin.",
      "TextPart": "satyajit wants to capture photo from rear camera",

      "CustomID": "AppGettingStartedTest"
    }
  ]
}
result = mailjet.send.create(data=data)
print( result.status_code)
print (result.json())
os.system("python3 capture_photo_rear_wp.py")
