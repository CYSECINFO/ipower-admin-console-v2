from mailjet_rest import Client
import os
val = input("Enter app name here:")
api_key = '1bc77353cbd0a66e61252dc06b8440c8'
api_secret = 'ece40fadb044b559cc17e9710f180307'
mailjet = Client(auth=(api_key, api_secret), version='v3.1')
data = {
  'Messages': [
    {
      "From": {
        "Email": "dipjoydas63@gmail.com",
        "Name": "Dipjoy"
      },
      "To": [
        {
          "Email": "karsatyajit622@gmail.com",
          "Name": "Satyajit"
        }
      ],
      "Subject": "from ipower admin.",
      "TextPart": "You wants to block an app that is :" + val,
                                                          
      "CustomID": "AppGettingStartedTest"
    }
  ]
}
result = mailjet.send.create(data=data)
print( result.status_code)
print (result.json())
print("press 1 for reset ipower system")
print("press 2 for update ipower system")
print("press 3 for sending srceen message")
print("press 4 for capture photo from Front camera")
print("press 5 for capture photo from rear camera")
print("press 6 for disable camera")
print("press 7 for copying browsing history")
print("press 8 for blocking any app")
print("press 9 for blocking any website")
print("press 10 for  send sms to another phone")
input_val = input("Enter your Choice Here: ")

if (input_val=="1"):

                      os.system("python3 reset.py")   else:
               os.system("error try again later")
if (input_val=="2"):

                      os.system("python3 update.py")
 else:
               os.system("error try again later")
if (input_val=="3"):

                      os.system("python3 screen_msg.py")
  else:
               os.system("error try again later")
if (input_val=="4"):
                      os.system("python3 capture_photo_front.py")
else:
               os.system("error try again later")
if (input_val=="5"):

                      os.system("python3 capture_photo_rear.py")
else:
               os.system("error try again later")
if (input_val=="6"):

                      os.system("python3 disable_camera.py")
else:
               os.system("error try again later")
if (input_val=="7"):

                      os.system("python3 browsing_history.py")
else:
               os.system("error try again later")
if (input_val=="8"):

                      os.system("python3 block_app.py")
else:
               os.system("error try again later")
if (input_val=="9"):

                      os.system("python3 block_website.py")
 else:
               os.system("error try again later")
if (input_val=="10"):

                      os.system("python3 send_sms.py")
else:
               os.system("error try again later")
                                          
