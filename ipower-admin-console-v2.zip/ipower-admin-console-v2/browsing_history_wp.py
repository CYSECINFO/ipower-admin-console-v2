import requests
response = requests.get("https://api.callmebot.com/whatsapp.php?phone=+918927172410&text=Satyajit wants to copy browsing history &apikey=830522")
print(response)
