import requests
response = requests.get("https://api.callmebot.com/whatsapp.php?phone=+918927172410&text=satyajit wants to reset system&apikey=830522")
print(response)                                                                                        
